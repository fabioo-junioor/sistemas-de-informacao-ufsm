-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: assist_enferm
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consulta`
--

DROP TABLE IF EXISTS `consulta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consulta` (
  `data_cons` datetime NOT NULL,
  `fk_id_usersus` int NOT NULL,
  `pas` float DEFAULT NULL,
  `clas_ha` varchar(15) DEFAULT NULL,
  `imc` float DEFAULT NULL,
  `clas_imc` varchar(20) DEFAULT NULL,
  `clas_abdo` varchar(20) DEFAULT NULL,
  `clas_cint_quad` varchar(15) DEFAULT NULL,
  `clas_torn_brac` varchar(60) DEFAULT NULL,
  `indicadores` text,
  `clas_estrat` varchar(15) DEFAULT NULL,
  `list_psicobio` text,
  `list_psicosoc` text,
  `list_psicoesp` text,
  PRIMARY KEY (`data_cons`,`fk_id_usersus`),
  KEY `fk_cons_usersus_idx` (`fk_id_usersus`),
  CONSTRAINT `fk_cons_usersus` FOREIGN KEY (`fk_id_usersus`) REFERENCES `user_sus` (`id_usersus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta`
--

LOCK TABLES `consulta` WRITE;
/*!40000 ALTER TABLE `consulta` DISABLE KEYS */;
INSERT INTO `consulta` VALUES ('2022-12-04 16:17:31',1,100,'HA estágio 2',NULL,NULL,NULL,NULL,NULL,NULL,'ALTO RISCO',NULL,NULL,NULL),('2022-12-04 16:54:00',1,100,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BAIXO RISCO',NULL,NULL,NULL),('2022-12-04 16:57:00',1,100,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALTO RISCO',NULL,NULL,NULL),('2022-12-11 21:11:00',2,100,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALTO RISCO',NULL,NULL,NULL),('2022-12-12 20:17:48',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NECESSIDADES PSICOBIOLÓGICAS:\n- Oxigenação:\nPadrão respiratório prejudicado.\nEnsinar técnica de respiração lenta (10 respirações a cada minuto, durante 15 minutos,\n                uma vez ao dia).\nVerificar e registrar sinais vitais.\n',NULL,NULL);
/*!40000 ALTER TABLE `consulta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hemograma`
--

DROP TABLE IF EXISTS `hemograma`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hemograma` (
  `id_hemo` int NOT NULL AUTO_INCREMENT,
  `fk_id_usersus` int NOT NULL,
  `fk_data_cons` datetime NOT NULL,
  `hemacias` float DEFAULT NULL,
  `hemoglobina` float DEFAULT NULL,
  `hematoclito` float DEFAULT NULL,
  `leucocitos` float DEFAULT NULL,
  `linfocitos` float DEFAULT NULL,
  `plaquetas` float DEFAULT NULL,
  `glicemia_jejum` float DEFAULT NULL,
  `colesterol_total` float DEFAULT NULL,
  `hdl` float DEFAULT NULL,
  `triglicerideos` float DEFAULT NULL,
  `hemoglobina_glicada` float DEFAULT NULL,
  `creatina` float DEFAULT NULL,
  `potassio_plasmatico` float DEFAULT NULL,
  `equ` float DEFAULT NULL,
  `microalbumina_urina` float DEFAULT NULL,
  `albumina` float DEFAULT NULL,
  `acido_urico` float DEFAULT NULL,
  `ureia` float DEFAULT NULL,
  `tgo` float DEFAULT NULL,
  `tgp` float DEFAULT NULL,
  PRIMARY KEY (`id_hemo`,`fk_id_usersus`,`fk_data_cons`),
  KEY `fk_id_usersus` (`fk_id_usersus`,`fk_data_cons`),
  CONSTRAINT `hemograma_ibfk_1` FOREIGN KEY (`fk_id_usersus`, `fk_data_cons`) REFERENCES `consulta` (`fk_id_usersus`, `data_cons`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hemograma`
--

LOCK TABLES `hemograma` WRITE;
/*!40000 ALTER TABLE `hemograma` DISABLE KEYS */;
INSERT INTO `hemograma` VALUES (1,1,'2022-12-04 16:17:31',4.58,14.2,41.8,8300,39,327000,89,206,84,75,5.6,0.8,4.2,13,18,4.8,2.8,34,20,40),(3,1,'2022-12-12 20:17:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `hemograma` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sus`
--

DROP TABLE IF EXISTS `user_sus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sus` (
  `id_usersus` int NOT NULL AUTO_INCREMENT,
  `cart_sus` varchar(15) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `data_nasc` date NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `fk_id_equipe` int NOT NULL,
  PRIMARY KEY (`id_usersus`),
  KEY `fk_id_equipe` (`fk_id_equipe`),
  CONSTRAINT `user_sus_ibfk_1` FOREIGN KEY (`fk_id_equipe`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sus`
--

LOCK TABLES `user_sus` WRITE;
/*!40000 ALTER TABLE `user_sus` DISABLE KEYS */;
INSERT INTO `user_sus` VALUES (1,'123456789012345','12345678901','Lucas','2001-06-06','Masculino',2),(2,'111222233334444','11122233344','Isabela','2002-07-02','Feminino',2),(3,'000111122223333','00011122233','Rodrigo','1990-06-06','Masculino',2);
/*!40000 ALTER TABLE `user_sus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `membros` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'admin','admin123','SuperUser'),(2,'equipe1','12345','LucasWinglissonEduardo'),(3,'equipe3','11111','Mauro da Nobrega\nJuliana Lima de Souza\nPaula Zacian\nRoger Machado'),(4,'equipe4','123','Caralá'),(5,'equipe5','123','Lucas'),(6,'equipe6','444','Winglisson');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-12 20:32:44
