package com.example.electoralpartials.model;

public class Cidade {
    private String idMunicipio;
    private String nome;

    public String getId() {
        return idMunicipio;

    }
    public void setId(String id) {
        this.idMunicipio = id;

    }
    public String getNome() {
        return nome;

    }
    public void setNome(String nome) {
        this.nome = nome;

    }
}
