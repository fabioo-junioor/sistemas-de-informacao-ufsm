package com.example.electoralpartials.model;

public class UserLogado {
    private String email;
    private String permAdmin;

    public String getEmail() {
        return email;

    }
    public void setEmail(String email) {
        this.email = email;

    }
    public String getPermAdmin() {
        return permAdmin;

    }
    public void setPermAdmin(String permAdmin) {
        this.permAdmin = permAdmin;

    }
}
