package com.example.electoralpartials.model;

public class Secao {
    private String numero;

    public String getNumero() {
        return numero;

    }
    public void setNumero(String numero) {
        this.numero = numero;

    }
}
