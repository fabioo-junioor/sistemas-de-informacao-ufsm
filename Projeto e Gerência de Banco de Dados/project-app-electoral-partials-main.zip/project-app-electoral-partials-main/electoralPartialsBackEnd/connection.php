<?php

$host = "127.0.0.1";
$user = "root";
$pass = "";
$db = "electoral";

/*
$host = "162.241.2.202";
$user = "patrim06";
$pass = "#QJPnw%zNT!A7";
$db = "patrim06_electoral";
*/

$con = mysqli_connect($host, $user, $pass, $db);

?>