<?php

$host = "127.0.0.1";
$user = "root";
$pass = "";
$db = "electoraltse";

/*
$host = "162.241.2.202";
$user = "patrim06";
$pass = "#QJPnw%zNT!A7";
$db = "patrim06_electoraltse";
*/

$con2 = mysqli_connect($host, $user, $pass, $db);

?>